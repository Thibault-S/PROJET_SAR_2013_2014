import java.net.*;
import java.io.*;
//elhaddad@lamsade.dauphine.fr

public class ThreadControleur extends Thread{
	
		
		
	
	
	
	
	
	
}